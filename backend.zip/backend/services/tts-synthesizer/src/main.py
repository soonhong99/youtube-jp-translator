import os
import uuid
import torch
from fastapi import FastAPI, Query
from fastapi.responses import FileResponse
from TTS.api import TTS

# Radam 관련 오류 방지용 패치
torch.serialization.add_safe_globals([("TTS.utils.radam", "RAdam")])

# FastAPI 앱 초기화
app = FastAPI()

# 지원 언어별 모델 정보
MODEL_MAP = {
    "ja": {
        "model_name": "tts_models/ja/kokoro/tacotron2-DDC",
        "vocoder_name": "vocoder_models/ja/kokoro/hifigan_v1"
    },
    "ko": {
        "model_name": "tts_models/ko/kss/tacotron2-DDC",
        "vocoder_name": "vocoder_models/ko/kss/hifigan_v1"
    }
}

# 임시 오디오 파일 저장 디렉토리 생성
AUDIO_DIR = "/tmp/tts-audio"
os.makedirs(AUDIO_DIR, exist_ok=True)

@app.get("/synthesize")
def synthesize(text: str = Query(...), lang: str = Query(...)):
    if lang not in MODEL_MAP:
        return {"error": f"Language '{lang}' is not supported."}

    model_info = MODEL_MAP[lang]

    # TTS 객체 생성
    tts = TTS(model_name=model_info["model_name"], vocoder_path=model_info["vocoder_name"])

    # 고유 파일명 생성 및 경로 설정
    filename = f"{uuid.uuid4().hex}.wav"
    output_path = os.path.join(AUDIO_DIR, filename)

    # 음성 합성 및 파일 저장
    tts.tts_to_file(text=text, file_path=output_path)

    # 오디오 파일 응답 반환
    return FileResponse(output_path, media_type="audio/wav", filename="output.wav")